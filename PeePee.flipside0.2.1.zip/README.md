Adds flipside

Map created using Pebbers map editor

Flipside is a custom mode and map combination based on the Effect and cause mission from the campaign, This modifier ONLY works on glitch and when enabled will cause the map to be split in two with players given a modified phase that will teleport you to your relative position on the other side of the map.

In the event you get stuck clients can type !Stuck in console to be moved

All changes made to the super phase.nut and the phase dash .nut are based on the modifier being active, if the modifier is disabled the weapons will act as normal
